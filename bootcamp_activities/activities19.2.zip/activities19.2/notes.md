npm install -g create-react-app yarn

create-react-app reactpractice

yarn install
yarn start


<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0/css/bootstrap.min.css"/>

***

If we want to render multiple JSX elements, they should be contained within a single parent element, such as a div.

Void elements, such as input tags, are represented by JSX tags with a self-closing forward slash, i.e. <input />.

We need to import the react library anywhere that we are utilizing JSX.

We use className instead of class because class is a reserved word in JavaScript.






-->Desktop
        -->React19.1
                --> Activities
                --> React-App








import React from "react";

const Card = () => (
  <div className="card">
    <div className="card-body">
      <p className="card-text">
        Aliquip dolore commodo nostrud minim. Cillum do enim non ullamco. Commodo magna eu ex mollit
        sunt amet fugiat. In irure eu enim id ea sit nostrud incididunt ad adipisicing.Aliquip
        dolore commodo nostrud minim. Cillum do enim non ullamco. Commodo magna eu ex mollit sunt
        amet fugiat. In irure eu enim id ea sit nostrud incididunt ad adipisicing.
      </p>
    </div>
  </div>
);

export default Card;

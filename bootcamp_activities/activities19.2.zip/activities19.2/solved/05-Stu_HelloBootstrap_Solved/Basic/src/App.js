import React from "react";
import HelloBootstrap from "./components/HelloBootstrap";

const App = () => <HelloBootstrap />;

export default App;


const numberTimesTwo = x => x * 2;
console.log(`numberTimesTwo * 5: ${numberTimesTwo(5)}`);

/*
var numberTimesTwo = function(x){
return x * 2
};

console.log('numberTimesTwo * 5 : \n' + numberTimesTwo(5));
*/

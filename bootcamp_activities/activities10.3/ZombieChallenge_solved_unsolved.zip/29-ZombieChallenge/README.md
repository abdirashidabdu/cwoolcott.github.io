# Zombie Challenge

## Files

* [`zombiegame.js`](Unsolved/zombiegame.js)

* [`ZombieGame.mp4`](Unsolved/ZombieGame.mp4)

## Instructions

* Follow the instructions in `zombiegame.js` to create a turn-based Zombie RPG game. You can also reference the video sent to you to have a clearer idea of what the final product should look like.

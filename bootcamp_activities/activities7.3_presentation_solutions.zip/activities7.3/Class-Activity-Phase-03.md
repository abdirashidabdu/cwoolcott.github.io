# Employee Data Management - Child_Added

## File

* *None*

## Instructions

* Using your newfound knowledge of the `.on("child_added")` method, begin to retrieve your employee data from the database and populating the records into your table.

* **NOTE:** Don't worry about calculating Months Worked or the Total Billed just yet. Just focus on retrieving the data that is already in the database.

* If you finish easily, continue refining the aesthetics of your website, consider incorporating "update" or "delete" employee buttons, or begin reading up on the MomentJS library.

# Employee Data Management - Push

## File

* *None*

## Instructions

* Using your newfound knowledge of the `.push({})` method, create the code necessary to push employee data into the database upon clicking the `submit` button on your webpage.

* **NOTE:** Don't worry about getting the data to display in the HTML just yet. Just focus on getting data pushed to the database.

* If you finish early, begin reading about `.on("child_added")` in the Firebase documentation and/or the MomentJS library.

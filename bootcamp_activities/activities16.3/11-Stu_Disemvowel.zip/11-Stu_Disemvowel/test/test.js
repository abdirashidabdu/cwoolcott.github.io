var expect = require("chai").expect;
var disemvowel = require("../disemvowel");

describe("Disemvowel", function() {

});
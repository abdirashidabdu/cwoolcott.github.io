
DROP DATABASE IF EXISTS database_development;
CREATE DATABASE database_development;